<h1>Canais</h1>
<a href="?acao=inserir">Inserir canal</a>
<table>
    <tr>
        <th>#</th>
        <th>Nome do Canal</th>
    </tr>

    <?php foreach ($canais as $canal): ?>
        <tr>
            <td><?= $canal->getId(); ?></td>
            <td><a href="?acao=exibir&id=<?= $canal->getId(); ?>"><?= $canal->getNome(); ?></a></td>
        </tr>
    <?php endforeach; ?>

</table>