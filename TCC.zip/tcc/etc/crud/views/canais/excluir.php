<h2>Excluir Canal</h2>

<form method="post" action="?acao=excluir">

    <label for="nome">Nome</label>
    <input type="hidden" name="id" value="<?= $canal->getId(); ?>">
    <input type="text" name="nome" id="nome" value="<?= $canal->getNome(); ?>" disabled/>
    <br>
    <label for="link">Link</label>
    <input type="text" name="link_canal" id="link" value="<?= $canal->getLink(); ?>" disabled/>
    <br>

    <input type="submit" name="gravar" value="Gravar"/>

</form>