<h2>Inserir Canal</h2>

<form method="post" action="?acao=inserir">

    <label for="nome">Nome</label>
    <input type="text" name="nome" id="nome" />
    <br>
    <label for="link">Link</label>
    <input type="text" name="link" id="link" />
    <br>
    <input type="submit" name="gravar" value="Gravar"/>

</form>