<h1>Detalhes do Canal- <?= $canal->getNome();?></h1>
<p>Canal: <?= $canal->getLink(); ?></p> <!-- TRANSFORMAR EM LINK -->

<a href="?acao=alterar&id=<?= $canal->getId(); ?>">Editar o canal</a>
<br>
<a href="?acao=excluir&id=<?= $canal->getId(); ?>">Excluir o canal</a>