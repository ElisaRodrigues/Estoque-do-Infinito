    <?php

    require_once '../database/Conexao.php';
    require_once '../models/Produto.php';

    class CrudProdutos{
        
        private $conexao;
        private $produto;
        
        public function __construct(){
            $this->conexao = Conexao::getConexao();
        }

        //cadastrar produto
        //EM PRODUÇÃO
        public function cadastrar(Produto $produto){
            $sql = "INSERT INTO produtos (nome, preco, referencia, estoque, estoque_min, descricao,  idTipoProduto) 
                    VALUES ('{$produto->nome}', {$produto->preco}, {$produto->referencia}, {$produto->estoque}, {$produto->estoqueMin}, 
                    '{$produto->descricao}', {$produto->tipoProduto})";
            $this->conexao->exec($sql);
            $id = $this->conexao->lastInsertId();

            //imagem
            $sqlImg = "INSERT INTO  imagem (imagem) VALUE ('$produto->imagem')";
            $this->conexao->exec($sqlImg);
            $idImagem = $this->conexao->lastInsertId();

            //cor
            $sqlCor = "INSERT INTO  cor (cor) VALUE ('$produto->cor')";
            $this->conexao->exec($sqlCor);
            $idCor = $this->conexao->lastInsertId();

            //tamanho
            $sqlTamanho = "INSERT INTO  tamanho (tamanho) VALUE ('$produto->tamanho')";
            $this->conexao->exec($sqlTamanho);
            $idTamanho = $this->conexao->lastInsertId();


            //prod_tamanho
            $pt = "insert into prod_tamanho (tam_id_tam, prod_id_prod) values ({$produto->tamanho}, {$id})";
            @$this->conexao->exec($pt);

            //prod_imagem
            print_r($idImagem);
            print_r($id);
            $pi = "insert into prod_imagem (img_id_img, prod_id_prod) values ({$idImagem}, {$id})";
            @$this->conexao->exec($pi);

            //prod_cor
            $pc = "insert into prod_cor (cor_id_cor, prod_id_prod) values ({$idCor}, {$id})";
            @$this->conexao->exec($pc);
        }

        //retorna os tipos de produtos
        //OKAY
        public function getTiposProduto(){
            $res = $this->conexao->query("select * from tipo_produto order by tipo");
            $tipos = $res->fetchAll(PDO::FETCH_ASSOC);
            return $tipos;
        }

        //retorna os tamanhos dos produtos
        //OKAY
        public function getTamanhos(){
            $res = $this->conexao->query("select * from tamanho order by tamanho");
            $tamanhos = $res->fetchAll(PDO::FETCH_ASSOC);
            return $tamanhos;
        }

        //retorna as cores dos produtos
        //OKAY
        public function getCores(){
            $res = $this->conexao->query("select * from cor order by cor");
            $cores = $res->fetchAll(PDO::FETCH_ASSOC);
            return $cores;
        }

        //retorna todos produtos em forma de um array associativo
        //OKAY
        public function getProdutos(){
            $consulta = $this->conexao->query("SELECT * FROM produtos");

            $arrayProdutos = $consulta->fetchAll(PDO::FETCH_ASSOC);

            return $arrayProdutos;
        }

        public function getImagens(){
            $consulta = $this->conexao->query("SELECT * FROM imagem");

            $imagens = $consulta->fetchAll(PDO::FETCH_ASSOC);

            return $imagens;
        }

        //retorna um produto em forma de array associativo
        //OKAY
        public function getProduto($id){
            $consulta = $this->conexao->query("SELECT * FROM produtos WHERE idProdutos = {$id}");
            $produto = $consulta->fetch(PDO::FETCH_ASSOC);
            return new Produto($produto['nome'], $produto['preco'], $produto['referencia'], $produto['estoque'], $produto['estoque_min'], $produto['descricao'],
                               $produto['tamanho'], $produto['cor'], $produto['idTipoProduto'], $produto['imagem'], $produto['id_produto'] );
        }

        //editar produtos
        //FAZEEEEEEEEEEEEEEEER
        public function editar($id, $produto){
            $this->conexao->exec("UPDATE Produtos SET '{$produto->nome}'                                                             
                                                                 {$produto->preco},
                                                                 {$produto->referencia},
                                                                 {$produto->estoque},
                                                                 {$produto->estoqueMin}, 
                                                                '{$produto->descricao}', 
                                                                '{$produto->tamanho}', 
                                                                '{$produto->cor}',
                                                                 {$produto->idTipoProduto}
                                                                 {$produto->imagem},
                                                                 {$produto->id_produto}
            WHERE id_produto = {$id}");
        }
    }

    $prod = new Produto("Teste", 200, 344, 100, "bla", "", "vermelha", "casaco","", "","" );

    $crud = new CrudProdutos();

    $crud->getProdutos();