<?php
session_start();
require 'Conection/conexao.php';

$email= $_POST['email'];
$senha= $_POST['senha'];
//$descript = md5($senha);


$wary = "SELECT * FROM usuarios WHERE email = '{$email}' AND senha = '{$senha}'"; //$descript na senha
$exec = $conexao->query($wary);
$result = $exec;
if (mysqli_num_rows($result) != 1){
    $_SESSION['error_login'] = "Error - Usuario ou Senha Inválidos";
    header("Location: http://localhost/tcc/app/views/login.html");
}else{
    $result = mysqli_fetch_assoc($result);
    $_SESSION['id_user'] = $result['idUsuarios'];
    $_SESSION['nome'] = $result['nome'];

    header("Location: http://localhost/tcc/app/controllers/produto_controller.php?acao=listarVend");
}