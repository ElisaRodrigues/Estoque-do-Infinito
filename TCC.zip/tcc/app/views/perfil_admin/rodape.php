
<script src="http://localhost/tcc/assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="http://localhost/tcc/assets/js/bootstrap.min.js"></script>
<!-- METISMENU SCRIPTS -->
<script src="http://localhost/tcc/assets/js/jquery.metisMenu.js"></script>
<!-- MORRIS CHART SCRIPTS -->
<script src="http://localhost/tcc/assets/js/morris/raphael-2.1.0.min.js"></script>
<script src="http://localhost/tcc/assets/js/morris/morris.js"></script>
<!-- CUSTOM SCRIPTS -->
<script src="http://localhost/tcc/assets/js/custom.js"></script>





</body>
</html>