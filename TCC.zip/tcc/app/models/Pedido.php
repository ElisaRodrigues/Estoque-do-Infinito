<?php


class Pedido
{
    private $data_hora;
    private $id_pedido;
    private $id_cliente;
    private $d_forma_pagamento;

    private function cancelarPedido(){

    }
    private function confirmarPedido(){

    }



}
